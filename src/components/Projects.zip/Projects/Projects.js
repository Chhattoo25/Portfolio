import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import ProjectCard from "./ProjectCards";

import leaf from "../../Assets/Projects/leaf.png";
import emotion from "../../Assets/Projects/emotion.jpeg";

import suicide from "../../Assets/Projects/suicide.png";


function Projects() {
  return (
    <Container fluid className="project-section" id="project">
      {/* <Particle /> */}
      <Container>
        <h1 className="project-heading">
          My  <strong className="purple">Peojects </strong>
        </h1>
        <p style={{ color: "white" }}>
          Here are a Some projects
        </p>
        <Row style={{ justifyContent: "center", paddingBottom: "10px" }}>
          <Col md={4} className="project-card">
            <ProjectCard
              src="https://camo.githubusercontent.com/e5a2e8de2e59d52381709341b1b66dca18a6f0b6de64593137733af0f5ecf364/68747470733a2f2f63646e2e686173686e6f64652e636f6d2f7265732f686173686e6f64652f696d6167652f75706c6f61642f76313633393932373138353137372f6469544e6f497234712e706e673f773d3136303026683d383430266669743d63726f702663726f703d656e74726f7079266175746f3d636f6d7072657373"
              isBlog={false}
              title="bella-vita-organic"
              description="Bella Vita Organic, Inc. is an Indian Health care Organic store. Founded in 2005 by W. Verman and F. Walia, it originated as a Organic Products store and evolved into a full-line retailer with departments for Hair Care, Skin Care, Body Care, cosmetics, and fragrances..."
              link="https://github.com/chhavi48/Bella-Vita-Organic"
            />
          </Col>

          <Col md={4} className="project-card">
            <ProjectCard
              src="https://user-images.githubusercontent.com/77965216/161383198-0b12af05-3c65-464b-80f5-35252704ea0f.JPG"
              isBlog={false}
              title="Small-case-website"
              description="we have cloned the SmallCase Website within 5 days this is the E-investing company. smallCase account that allows an investor to buy and sell tradable securities based on the predefined combinations."
              link="https://github.com/chhavi48/smallCase-clone"
            />
          </Col>

          <Col md={4} className="project-card">
            <ProjectCard
              src="https://camo.githubusercontent.com/865b8ec6b8a17a32f26769ad88a80f069f82d1015c765d716d9b9d47ccf1c266/68747470733a2f2f6d69726f2e6d656469756d2e636f6d2f6d61782f313035302f312a32513975644a687272535f496165526244564c3870512e6a706567"
              isBlog={false}
              title="Nature-Basket"
              description="we have cloned the Nature’s Basket Website this is an E-Commerce Website for helping this site you can buy the nature-related product and find the details of the product .at the end of unit Masai team is assigned a project and the project is based on the technology we are learned in the whole unit in this project we are used React- Redux and React -Router-Dom."
              link="https://github.com/chhavi48/clone-of-Natures-Basket"
            />
          </Col>

          <Col md={4} className="project-card">
            <ProjectCard
              src="https://user-images.githubusercontent.com/77965216/162609373-4b4327d0-ef6d-4c5c-bcb3-245f3fbb8101.JPG"
              isBlog={false}
              title="Youtube Clone"
              description=""
              link="https://github.com/chhavi48/api-class-project"
            />
          </Col>

          <Col md={4} className="project-card">
            <ProjectCard
              src="https://pbs.twimg.com/ext_tw_video_thumb/1403911292591611905/pu/img/R3_e8jOvhmhEI5uZ?format=jpg&name=large"
              isBlog={false}
              title="Car Animation"
              description="i have done 100+ animations with only css "
              link="https://github.com/chhavi48/moving-car"
            />
          </Col>

          <Col md={4} className="project-card">
            <ProjectCard
              src="https://user-images.githubusercontent.com/77965216/170807531-65f9c728-e574-43fe-8563-8c5aa7301f12.png"
              isBlog={false}
              title="HandGesture"
              description=""
              link="https://github.com/chhavi48/GestureRecognition"
            />
          </Col>
        </Row>
      </Container>
    </Container>
  );
}

export default Projects;
